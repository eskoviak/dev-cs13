<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata">
    <label>eloqua2@redwingshoes.com.test</label>
    <protected>false</protected>
</CustomMetadata>
